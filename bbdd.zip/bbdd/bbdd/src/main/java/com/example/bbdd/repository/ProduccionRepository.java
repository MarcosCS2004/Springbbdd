package com.example.bbdd.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.bbdd.entity.Produccion;


public interface ProduccionRepository extends JpaRepository<Produccion, Long>{

}
