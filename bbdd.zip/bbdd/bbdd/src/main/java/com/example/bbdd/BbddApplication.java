package com.example.bbdd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BbddApplication {

	public static void main(String[] args) {
		SpringApplication.run(BbddApplication.class, args);
	}

}
