package com.example.bbdd.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.bbdd.entity.Clasificacion;

public interface ClasificacionRepository extends JpaRepository<Clasificacion, Long>{

}
