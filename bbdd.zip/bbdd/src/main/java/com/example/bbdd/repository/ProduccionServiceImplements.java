package com.example.bbdd.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bbdd.entity.Clasificacion;
import com.example.bbdd.entity.Produccion;

@Service
public class ProduccionServiceImplements implements DAOService {
	
	@Autowired
	ClasificacionRepository clasificacionRepository;
	
	@Autowired
	ProduccionRepository produccionRepository;

	
	@Override
	public void saveClasificacion(Clasificacion clasificacion) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteClasificacion(Long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Clasificacion> listaCategorias() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Clasificacion findClasificacionById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveProduccion(Produccion produccion) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Produccion> listaProducciones() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Produccion findProduccionById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteProduccion(Long id) {
		// TODO Auto-generated method stub
		
	}

}
