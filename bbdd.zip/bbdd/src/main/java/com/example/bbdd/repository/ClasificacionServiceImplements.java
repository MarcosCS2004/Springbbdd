package com.example.bbdd.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bbdd.entity.Clasificacion;
import com.example.bbdd.entity.Produccion;

@Service
public class ClasificacionServiceImplements implements DAOService{
	
	@Autowired
	private ClasificacionRepository clasificacionRepository;
	
	@Autowired
	private ProduccionRepository produccionRepository;

	@Override
	public void saveClasificacion(Clasificacion clasificacion) {
		clasificacionRepository.save(clasificacion);
	}

	@Override
	public List<Clasificacion> listaCategorias() {
		return clasificacionRepository.findAll();
	}

	@Override
	public void deleteClasificacion(Long id) {
		clasificacionRepository.deleteById(id);
	}

	@Override
	public Clasificacion findClasificacionById(Long id) {
		return clasificacionRepository.findById(id).orElse(null);
	}

	@Override
	public void saveProduccion(Produccion produccion) {
		produccionRepository.save(produccion);
	}

	@Override
	public List<Produccion> listaProducciones() {
		return produccionRepository.findAll();
	}

	@Override
	public Produccion findProduccionById(Long id) {
		return produccionRepository.findById(id).orElse(null);
	}

	@Override
	public void deleteProduccion(Long id) {
		produccionRepository.deleteById(id);
	}

	

}
